# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['maintenances',
 'maintenances.custom_napalm',
 'maintenances.custom_napalm.utils',
 'maintenances.lib',
 'maintenances.utils']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML>=6.0,<7.0',
 'atlassian-python-api>=3.18.1,<4.0.0',
 'dictdiffer>=0.9.0,<0.10.0',
 'ipaddress>=1.0.23,<2.0.0',
 'keyring>=23.5.0,<24.0.0',
 'lxml>=4.7.1,<5.0.0',
 'napalm>=3.3.1,<4.0.0',
 'netaddr>=0.8.0,<0.9.0',
 'pandas>=1.4.0,<2.0.0',
 'pydantic>=1.9.0,<2.0.0',
 'pygsheets>=2.0.5,<3.0.0',
 'pyotp>=2.6.0,<3.0.0',
 'textfsm>=1.1.2,<2.0.0',
 'typer>=0.4.0,<0.5.0']

setup_kwargs = {
    'name': 'maintenances',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'josh-work',
    'author_email': 'jdickman@cenic.org',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
